"use strict";
document.querySelectorAll("select[data-language-base]").forEach((select)=>{
 select.addEventListener("change",()=>{
  const valid=["en","tr","ru","es","pt-BR","fr","th","ms","id","ar","zh-CN","ja","ko"];
  if(!valid.includes(select.value))return;
  const base=new URL(select.dataset.languageBase,document.baseURI);
  const page=select.dataset.page||"";
  const target=new URL(select.value+"/"+(page?page+"/":""),base);
  if(target.origin===location.origin)location.assign(target.href);
 });
});
