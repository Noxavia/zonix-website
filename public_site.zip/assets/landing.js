"use strict";
(()=>{
 const valid=["en","tr","ru","es","pt-BR","fr","th","ms","id","ar","zh-CN","ja","ko"];
 const languages=navigator.languages||[navigator.language||"en"];
 let chosen="en";
 for(const raw of languages){
  const lower=raw.toLowerCase();
  if(lower.startsWith("pt")){chosen="pt-BR";break;}
  if(lower==="zh"||lower.startsWith("zh-cn")||lower.startsWith("zh-hans")||lower.startsWith("zh-sg")){chosen="zh-CN";break;}
  const base=lower.split("-")[0];
  if(valid.includes(base)){chosen=base;break;}
 }
 const target=new URL(chosen+"/",new URL("./",location.href));
 if(target.origin===location.origin)location.replace(target.href);
})();
